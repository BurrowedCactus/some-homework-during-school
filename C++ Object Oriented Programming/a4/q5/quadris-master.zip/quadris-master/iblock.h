#ifndef I_BLOCK_H
#define I_BLOCK_H
#include <vector>
#include "cell.h"

class IBlock : public Block{
//	vector<vector<Cell*>> theBlock;
//	Shape blockType;
//	size_t width;
//	size_t height;
//	Level* level;
public:
	IBlock ();
	vector<Info> cwInfo(Grid *g) override;
	vector<Info> ccwInfo(Grid *g) override;
};
#endif
