#include "iblock.h"

IBlock::IBlock():blockType{Shape::I} {
	for (size_t i = 0; i < blockSize; ++i) {
		//  if (spot->getInfo().blockType == Shape::EMPTY)
		theBlock.at(i)->getInfo().shape = Shape::I;
		theBlock.at(i)->getInfo().row = HEIGHT - 1; //top left corner
		theBlock.at(i)->getInfo().col = i;
	}
}

vector<Info> IBlock::cwInfo(Grid *g) {
	vector<Info> toReturn;
	for (size_t i = 0; i < blockSize; ++i){
		toReturn.emplace_back(Info{theBlock.col, theBlock.row, Shape::I});	
	}
	return toReturn;
}

vector<Info> IBlock:: ccwInfo(Grid *g){
	vector<Info> toReturn;
	for (size_t i = 0; i < blockSize; ++i){
		toReturn.emplace_back(Info{theBlock.col, theBlock.row, Shape::I});
	}
	return toReturn;
}


