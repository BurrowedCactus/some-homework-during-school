#include "quadris.h"
using namespace std;
/*
        std::unique_ptr<Level> level;
        std::unique_ptr<Score> score;
        std::unique_ptr<Block> currentBlock = nullptr;
        Shape nextShape = Shape::EMPTY;
	std::vector<unique_ptr<Block>> blockList;
	std::unique_ptr<TextDisplay> td;
        std::unique_ptd<GraphicDisplay> gd;
        std::unique_ptr<Grid> g;
*/

Quadries::Quadries(int winSize):
	level{make_unique<Level>()},
	score{make_unique<Score>()},
	Shape nextShape = ????? // generated from level
	td{make_unique<TextDisplay>(level, score, nextShape)},
	gd{make_unique<GraphicDisplay>(level, score, nextShape, winSize)},
	g{make_unique<Grid>(td,gd)}{}


void Quadris::genBlock(){
	if (nextShape == Shape::EMPTY) {
		nextShape = level->getNewShape();
	}
	switch (nextShape) {
		case Shape::I:
			currentBlock = make_unique<IBlock>(nextShape);
			break;
		case Shape::J:
			currentBlock = make_unique<JBlock>(nextShape);
			break;
		case Shape::L:
			currentBlock = make_unique<LBlock>(nextShape);
			break;
		case Shape::O:
			currentBlock = make_unique<OBlock>(nextShape);
			break;
		case Shape::S:
			currentBlock = make_unique<SBlock>(nextShape);
			break;
		case Shape::Z:
			currentBlock = make_unique<ZBlock>(nextShape);
			break;
		case Shape::T:
			currentBlock = make_unique<TBlock>(nextShape);
			break;
		default:
			currentBlock = make_unique<EMPTYBLock>(nextShape);
			break;
	}
	try {
		currentBlock->setBlock(g);
		blockList.emplace_back(std::move(currentBlock));
		nextShape = level->getNewShape();
	} catch (GameOver &) {}
}
	

void Quadris::drop(){
	try {
		while(true){
			 currentBlock->moveDown(g);
		} 
	} catch {InvalidMove&} {}
	
	// clear full lines, if any
	vector<size_t> clear = g->checkClear();

	// update theBlock in blocklist
	for (auto &clearLine : clear){
		for (auto &b : blockList){
			b->updateClear(clearLine);
		}
	}

	// update current scores, 2 steps
	score->setCurrentScore(score->getCurrentScore() + pow (level->getLevel() + clear, 2));
	for (auto &b :blockList) {
		if (b->getSize() == 0) {
			score->setCurrentScore(score->getCurrentScore + b->getScore);
			blockList.erase(b); 
		}
		
	}
	// update Highest Score
	if (score->getCurrentScore() > score->getHighScore()) score->setHighScore(score->getCurrentScore); 
        genBlock();
}


void Quadris::moveLeft(){
	try {
		currentBlock->moveLeft(g);	
	} catch {InvalidMove &} {}	
}

void moveRight();
void moveUp();
void moveDown();
void clockwise();
void counterClockwise();







