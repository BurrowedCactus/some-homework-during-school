#include "grid.h"
using namespace std;
/*
const size_t WIDTH = 11;
const size_t HEIGHT = 15;
const size_t BUFFER_HEIGHT = 3;

//cell + void clear()
//block + moveDown throw exception indicate end

class Grid { 
	std::vector<Block> list;
	std::vector<std::vector<Cell>> theGrid;
	std::unique_ptr<Block> currentBlock;
	std::unique_ptr<TextDisplay> td; 
	std::unique_ptr<GraphicsDisplay> gd;  
	std::unique_ptr<Score> score;
};
*/

/*
size_t min (size_t a, size_t b){
	return (a < b)? a : b;
}

size_t max (size_t a, size_t b){
	return (a < b)? b : a;
}
*/

Grid::Grid(TextDisplay* td, GraphicsDisplay* gd):td{td},gd{gd}{
	for (size_t i = 0; i < WIDTH; ++i){
		vector<Cell> temp;
		for (size_t j = 0; j < HEIGHT + BUFFER_HEIGHT; ++j){
			Cell newCell{i, j, Shape::EMPTY};
			temp.emplace_back(newCell);
		}
		theGrid.emplace_back(temp);
	}
	setObserver();
}

//~Grid(){}

void Grid::setObserver(){
	for (size_t i = 0; i < WIDTH; ++i){
		for (size_t j = 0; j < HEIGHT + BUFFER_HEIGHT; ++j){
/*			size_t colMin = max(i - 1, 0);
			size_t colMax = min(i + 1, WIDTH);
			size_t rowMin = max(j - 1, 0);
			size_t rowMax = min(j + 1, HEIGHT + BUFFER_HEIGHT);
			for (size_t x = rowMin; x < rowMax; ++x){
				theGrid.at(i).at(j).attach(&theGrid.at(x).at(j));
			}
			for (size_t x = colMin; x < colMax; ++x){
				theGrid.at(i).at(j).attach(&theGrid.at(i).at(x));
			}
*/
			//theGrid.at(i).at(i).attach(currentBlock.get());
			theGrid.at(i).at(i).attach(td);
			theGrid.at(i).at(i).attach(gd);
		}
	}
}
//
void Grid::restart(){
	for (size_t i = 0; i < WIDTH; ++i){
		vector<Cell> temp;
		for (size_t j = 0; j < HEIGHT + BUFFER_HEIGHT; ++j){
			Cell newCell{i, j, Shape::EMPTY};
			temp.emplace_back(newCell);
		}
	theGrid.emplace_back(temp);
	}
}

void Grid::clearLine(size_t line){
	for (size_t i = line; i < HEIGHT; ++i){
		for (size_t j = 0; j < WIDTH; ++ j){
			Cell cell = theGrid.at(i).at(j);
			cell.setShape(Shape::EMPTY);
			if (i != HEIGHT - 1) {			
				cell.setShape(theGrid.at(i + 1).at(j).getInfo().shape);
			}
			cell.notifyObserver(); // notidy td & gd
		}
	}
}

bool isLineFull(size_t line){
	for(auto& spot: theGrid.at(line)){
		if(spot.getInfo().shape == Shape::EMPTY){
			return false;
		}
	}
	return true;
}

vector<size_t> checkClear(){
	vector<size_t> clearLines;
	size_t maxRow = HEIGHT;
	for (size_t row = 0; row < maxRow; ++row){
		if (isLineFull(row)){
			clearLines.emplace_back(row);
			clearLine(row);
			--row;
			--maxRow;
		}
	}
	return clearLines;
}


/*
void Grid::drop(){
	while(true){
		try{
			currentBlock.moveDown();
		} catch (){
			break;
		}
	}
	checkClear();
	setBlock(level->getNewShape())
}
*/

/*
void setBlock(Shape newShape){
	switch (newShape) {
		case Shape::I:
			currentBlock = make_unique<IBlock>(newShape);
			list.emplace_back(currentBlock);
			break;
		case Shape::J:
			currentBlock = make_unique<JBlock>(newShape);
			list.emplace_back(currentBlock);
			break;
		case Shape::L:
		case Shape::O:
		case Shape::S:
		case Shape::Z:
		case Shape::T:
		default:
	}
	
	try{
		currentBlock->setBlock(Shape);
	} catch (...){
		throw "game over";
	}
}
*/

bool Grid::isCellEmpty(Info info){
	return theGrid.at(info.row).at(info.col).isEmpty();
}


void Grid::setEmpty(Info info){
	Cell cell =  theGrid.at(info.row).at(info.col);
	cell.setShape(Shape::Empty);	
}

// used in Block::setBlock can only apply to empty cell
void Grid::setShape (Info info) {
	Cell cell =  theGrid.at(info.row).at(info.col);
	cell.setShape(info.shape);
}

/*
void move(string direction){
	size_t height = currentBlock->width();
	size_t width = currentBlock->height();
	size_t row = currentBlock->getInfo().row;
	size_t col = currentBlock->getInfo().col;
	if (direction == "Left"){
		if (col > 0){
		vector<vector<Cell>> vertical;
			for (size_t i = row; i < row + height; ++i){
				vector<Cell> temp;
				temp.emplace_back(theGrid.at(col - 1).at(i));
			}
		currentBlock.moveLeft(vertical);
		}
	} else if (direction == "Right"){
		if (col < WIDTH - 1){
		vector<vector<Cell>> vertical;
			for (size_t i = row; i < row + height; ++i){
				vector<Cell> temp;
				temp.emplace_back(theGrid.at(col + 1).at(i));
			}
		currentBlock.moveRight(vertical);
		}
	} else if (direction == "Up"){
		if (row < HEIGHT + BUFFERHEIGHT - 1){
		vector<Cell> horizontal;
			for (size_t i = col; i < col + width; ++i){
				horizontal.emplace_back(theGrid.at(i).at(row + 1));
			}
		currentBlock.moveUp(vertical);
		}
        } else if (direction == "Down"){
		if (row > 0){
			vector<Cell> horizontal;
			for (size_t i = col; i < col + width; ++i){
				horizontal.emplace_back(theGrid.at(i).at(row - 1));
			}
			try{
				currentBlock.moveDown(vertical);
			} catch(...){
			
			}
		}
	} else {
	//height and width will be switched. check the possible state afterward.
		if (col + height < HEIGHT + BUFFERHEIGHT - 1 && row + width < WIDTH - 1){
			vector<vector<Cell>> rectangle;
			size_t side = max(height, width);
			for (size_t i = row; i < row + side; ++i){
				vector<Cell> temp;
				for (size_t j = col; j < col + side; ++j){
					vector<Cell> temp;
					temp.emplace_back(theGrid.at(col + 1).at(i));
				}
			}
			if(direction == "Cloclwise"){
				currentBlock->cloclwise(rectangle);
			} else {//"CounterClockwise"
				currentBlock->counterClockwise(rectangle);
			}
		}
	}
}

bool isFull(){
	
}

bool isGameOver(){
	return isFull();
}

};
*/
