# quadris

## reference:
- [Xlib manpage](https://www.niksula.hut.fi/~jkirma/books/xlib.pdf)
- [Xlib colors](http://cng.seas.rochester.edu/CNG/docs/x11color.html)
- [TrieNode auto complete](http://rmandvikar.blogspot.ca/2008/10/trie-examples.html)
- [2012](https://github.com/jacobwillemsma/Quadris)
- [2016](https://github.com/JiazhanSong/Quadris)
- [2011](https://github.com/franklixuefei/quadris)
