#include "display.h"
#include <string>
using namespace std;

string Display::getLevel(){
	return "Level:    " + duplicate(' ', format(score, level) - digit(level->getLevel())) +
				level->getLevel();
}

string Display::getScore(){
	return "Score:    " + duplicate(' ', format(score, level) - digit(score->getCurrentScore())) +
				score->getCurrentScore();
}

string Display::getHighScore(){
	return "Hi Score: " + duplicate(' ', format(score, level) - digit(score->getHighScore())) +
				score->getHighScore(); 
}

string Display::getStrNext(){
	return "Next:";
}


Display::Display(Level* level, Score* score, Shape* nextBlock):
		level{level}, score{score}, nextBlock{nextBlock} {}
//string strNext = "Next:";

string duplicate(char c, int i){
	string s;
	while(i > 0){
		s += c;
		--i;
	}
	return s;
}

int format(Score* score, Level* level){
	int temp = (digit(score->getCurrentScore) > digit(score->getHighScore))?
		digit(score->getCurrentScore) : digit(score->getHighScore);
	return (temp > digit(level->getLevel()))? temp : digit(level->getLevel());
}

int digit(int input){
	int answer = 0;
	while (input >0){
		input /= 10;
		++answer;
	}
	return answer;
}
