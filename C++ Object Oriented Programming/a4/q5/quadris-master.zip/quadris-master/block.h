#ifndef BLOCK_H
#define BLOCK_H
#include <vector>
#include "info.h"
#include "cell.h"
#include "grid.h"

class InvalidMove{};
class GameOver{};


class Block {

protected:
	vector<Info> theBlock;
	int level;
	size_t blockSize = 4;
	//Shape blockType;
	//size_t width;
	//size_t height;
	//size_t llrow = 0; // row coordiante of lower left cell
	//size_t llcol = 0; // col coordiante of lower left cell

	virtual vector<Info> cwInfo(Grid *g) = 0;
	virtual vector<Info> ccwInfo(Grid *g) = 0;

	

public:
	// YOU CANNOT CONSTRUCT A BLOCK SINCE IT IS ABSTRACT
	//virtual  ~Block() = default;
	//void setWidth(size_t w);
	//void setHeight(size_t h)
	//size_t getWidth();
	//size_t getHeight();
	//bool isValidMove();
	//throw exception if cannot set block

	//void setBlockType(Shape s);
	//Shape getBlockType();
	int getLevel();

	//void setLowerLeft(size_t r, size_t c);
	Info &getLowerLeft();
	bool isInBlock(Grid *g);
	void left(Grid *g);
	void right(Grid *g);
	void down(Grid *g);
	void up(Grid *g);
	void clockwise(Grid *g);
	void counterClockwise(Grid *g);
	void updateClear(size_t line);
	int getSize();
	int getScore();

#endif
