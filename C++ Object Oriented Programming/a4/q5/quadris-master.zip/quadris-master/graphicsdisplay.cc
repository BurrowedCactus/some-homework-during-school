#include <iostream>
#include "graphicsdisplay.h"
#include "info.h"
#include "subject.h"
#include "constants.h"
using namespace std;

GraphicsDisplay::GraphicsDisplay(Level* level, Score* score, Shape nextBlock, int winSize):
			Display{level, score, nextBlock}, winSize{winSize}, xw{winSize, winSize} {
	xw.fillRectangle(0, 0, winSize, winSize, Xwindow::Blue);
}

void drawNext(){
	int cellSize = winSize / (WIDTH + (BLOCK_SIZE + BUFFER_NEXTBLOCK) + BUFFER_STR);
	int row = (HIGHT_NEXT + BUFFER_NEXTBLOCK)/2;
	int col = (WIDTH + (BUFFER_STR + BUFFER_NEXTBLOCK)/2;
	switch(nextBlock){
		case Shape::I:
			xw.fillRectangle(col * cellSize, row * cellSize, 4 * cellSize, cellSize, Xwindow::Red);
			break;
		case Shape::J:
			xw.fillRectangle(col * cellSize, (row + 1) * cellSize, cellSize, cellSize, Xwindow::Green);
			xw.fillRectangle(col * cellSize, row * cellSize, 3 * cellSize, cellSize, Xwindow::Green);
			break;
		case Shape::L:
			xw.fillRectangle((col + 3) * cellSize, (row + 1) * cellSize, cellSize, cellSize, Xwindow::Blue);
			xw.fillRectangle(col * cellSize, row * cellSize, 3 * cellSize, cellSize, Xwindow::Blue);
			break;
		case Shape::O:
			xw.fillRectangle(col * cellSize, row * cellSize	, 2 * cellSize, 2 * cellSize, Xwindow::Pink);
			break;
		case Shape::S:
			xw.fillRectangle((col + 1) * cellSize, (row + 1) * cellSize, 2 * cellSize, cellSize, Xwindow::Yellow);
			xw.fillRectangle(col * cellSize, row * cellSize, 2 * cellSize, cellSize, Xwindow::Yellow);
			break;
		case Shape::Z:
			xw.fillRectangle(col * cellSize, (row + 1) * cellSize, 2 * cellSize, cellSize, Xwindow::Purple);
			xw.fillRectangle((col + 1) * cellSize, row * cellSize, 2 * cellSize, cellSize, Xwindow::Purple);
			break;
		case Shape::T:
			xw.fillRectangle(col * cellSize, (row + 1) * cellSize, 3 * cellSize, cellSize, Xwindow::Orange);
			xw.fillRectangle((col + 1) * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Orange);
			break;
		case Shape::EMPTY:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::White);
			break;
		default:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::White);
			break;
	}
}

void GraphicsDisplay::notify(Subject<Info, State> &whoNotified) {
	int row = whoNotified.getInfo().row;
	int col = whoNotified.getInfo().col;
	int cellSize = winSize / (WIDTH + (BLOCK_SIZE + BUFFER_NEXTBLOCK) + BUFFER_STR);
	whoNotified.getInfo().shape = theShape;
	switch(theShape) {
		case Shape::I
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Red);
			break;
		case Shape::J:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Green);
			break;
		case Shape::L:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Blue);
			break;
		case Shape::O:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Pink);
			break;
		case Shape::S:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Yellow);
			break;
		case Shape::Z:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Purple);
			break;
		case Shape::T:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::Orange);
			break;
		case Shape::EMPTY:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::White);
			break;
		default:
			xw.fillRectangle(col * cellSize, row * cellSize, cellSize, cellSize, Xwindow::White);
	}
	xw.drawString(WIDTH * cellSize + BUFFER * cellSize / 4 , (HEIGHT - 2) * cellSize, getLevel());
	xw.drawString(WIDTH * cellSize + BUFFER * cellSize / 4 , (HEIGHT - 3) * cellSize, getScore());
	xw.drawString(WIDTH * cellSize + BUFFER * cellSize / 4 , (HEIGHT - 4) * cellSize, getHighScore());
	xw.drawString(WIDTH * cellSize + BUFFER * cellSize / 4 , 
		      		(HEIGHT_NEXT + BUFFER_NEXTBLOCK + BLOCK_SIZE) * cellSize, getStrNext());
	drawNext();
}
