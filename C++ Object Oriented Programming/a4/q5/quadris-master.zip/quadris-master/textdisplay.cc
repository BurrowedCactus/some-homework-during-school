#include <vector>
#include "textdisplay.h"
using namespace std;

/*
**************************************************
the top and middle part should be finished.
the bottom part is not done, since it does not have access to the next block yet.
**************************************************
*/

vector<string> outputNext(Shape nextBlock){
	vector<string> answer;
	switch(nextBLock){
		case Shape::I:
			answer.emplace_back(string {"IIII"});
			break;
		case Shape::J:
			answer.emplace_back(string {"J"});
			answer.emplace_back(string {"JJJ"});
			break;
		case Shape::L:
			answer.emplace_back(string {"  L"});
			answer.emplace_back(string {"LLL"});
			break;
		case Shape::O:
			answer.emplace_back(string {"OO"});
			answer.emplace_back(string {"OO"});
			break;
		case Shape::S:
			answer.emplace_back(string {" SS"});
			answer.emplace_back(string {"SS"});
			break;
		case Shape::Z:
			answer.emplace_back(string {"ZZ"});
			answer.emplace_back(string {" ZZ"});
			break;
		case Shape::T:
			answer.emplace_back(string {"TTT"});
			answer.emplace_back(string {" T"});
			break;
		case Shape::EMPTY:
			answer.emplace_back(string {" "});
			break;
		case default:
			answer.emplace_back(string {" "});
			break;
	}
	return answer;
}

TextDisplay::TextDisplay(Level* level, Score* score, Shape nextBlock): 
		Display{level, score, nextBlock} {
	vector<char> row (width, ' ');
	for (int i = 0; i < height; ++i){
 		theDisplay.emplace_back(row);
 	}
}

void TextDisplay::notify(Subject<Info, State> &whoNotified){
	size_t r = whoNotified.getInfo().row;
	size_t c = whoNotified.getInfo().col;
	switch(whoNotified.getInfo().shape) {
		case Shape::I:
			theDisplay.at(r).at(c) = 'I';
			break;
		case Shape::J:
			theDisplay.at(r).at(c) = 'J';
			break;
		case Shape::L:
			theDisplay.at(r).at(c) = 'L';
			break;
		case Shape::O:
			theDisplay.at(r).at(c) = 'O';
			break;
		case Shape::S:
			theDisplay.at(r).at(c) = 'S';
			break;
		case Shape::Z:
			theDisplay.at(r).at(c) = 'Z';
			break;
		case Shape::T:
			theDisplay.at(r).at(c) = 'T';
			break;
		case Shape::EMPTY:
			theDisplay.at(r).at(c) = ' ';
			break;
		case default:
			theDisplay.at(r).at(c) = ' ';
			break;
	}	
}


ostream &operator<<(ostream &out, const TextDisplay &td){
	out << td.getLevel() << endl;
	out << td.getScore() << endl;
	out << td.getHighScore() << endl; 

	for (int i = 0; i < td.gridSize; ++i){
		for (int j = 0; j < td.gridSize; ++j){
			out << td.theDisplay.at(i).at(j);
		}
		out << endl;
	}
	
	out << getStrNext() << endl;
	auto temp = outputNext(*nextBlock);
	for (auto& line: temp){
		out << line << endl;
	}
	return out;
}
