#include "block.h"



//size_t Block::getWidth(){
  //return theBlock.at(0).length();
//}
//size_t Block::getHeight(){
//	return theBlock.length();
//}
//bool Block::isValidMove();

//throw exception if cannot set block
//grid is half changed, weak exception safe


/*
void Block::setLowerLeft(size_t r, size_t c){
	llrow = r;
	llcol = c;
	for (size_t i = 0; i < blockSize; ++i){
		theBlock.at(i)->getInfo().row += r;
		theBlock.at(i)->getInfo().col += c;
	}
}
*/





// used to set Block in Grid (Quadries::genBlock()), after concrete block has been created 
void Block::setBlock(Grid *g){
	// can we set new Block?
	for(auto &info: theBlock){
		if ((!g->isCellEmpty(info))) {
			throw GameOver{};
		}
	}
	
	// set new block in grid
	for(auto &info: theBlock){
		 g->setShape(info);
	}
}


/*
	for(auto& line: theBlock){
		for(auto& spot: line){
			if (spot->getInfo().blockType == Shape::EMPTY){
				spot->setShape(shape);
			}else{
				throw;
			}
		}
	}
}*/

bool Block::isInBlock(const Info &info){
	for (size_t i = 0; i < blockSize; ++i){
		if (theBlock.at(i)->getInfo().row == info.row && theBlock.at(i)->getInfo().col == info.col) return true;
        }
	return false;
}


void Block::moveLeft(Grid *g){
	for(size_t i = 0; i < BlockSize; ++i){ 
		Info info = theBlock.at(i);
		if (info.col = 0) throw InvalidMove{};
		--info.col; // position of cell on the left, NOT change theBlock
		// left cell is not in Block && left Cell is not empty
		if ((!isInBlock(info)) && (!g->isCellEmpty(info))) throw InvalidMove{};
	}

	for(size_t i = 0; i < BlockSize; ++i){
		g->setEmpty(theBlock.at(i)); // clear original block in grid
	}

	for(size_t i = 0; i < BlockSize; ++i){
		--theBlock.at(i).col; // update block
		g->setShape(theBlock.at(i)); // update grid
	} 
}

void Block::moveRight(){
	for(size_t i = 0; i < BlockSize; ++i){
		Info info = theBlock.at(i);
		if (info.col = 11 - 1) throw InvalidMove{}; //TODO::constanct
		++info.col; 
		if ((!isInBlock(info)) && (!g->isCellEmpty(info))) throw InvalidMove{};
	}

	for(size_t i = 0; i < BlockSize; ++i){
		g->setEmpty(theBlock.at(i)); // clear original block in grid
	}

	for(size_t i = 0; i < BlockSize; ++i){
		++theBlock.at(i).col; // update block
		g->setShape(theBlock.at(i)); // update grid
	}
}


void Block::moveDown(){
	for(size_t i = 0; i < BlockSize; ++i){
		Info info = theBlock.at(i);
		if (info.row = 0) throw InvalidMove{};
		--info.row; // position of cell downside
		if ((!isInBlock(info)) && (!g->isCellEmpty(info))) throw InvalidMove{};
	}

	for(size_t i = 0; i < BlockSize; ++i){
		g->setEmpty(theBlock.at(i)); // clear original block in grid
	}

	for(size_t i = 0; i < BlockSize; ++i){
		--theBlock.at(i).row; // update block
		g->setShape(theBlock.at(i)); // update grid
	}
}

void Block::moveUp(){
	for(size_t i = 0; i < BlockSize; ++i){
		Info info = theBlock.at(i);
		if (info.row = 15 - 1) throw InvalidMove{}; //TODO:: constant
		++info.row; // 
		if ((!isInBlock(info)) && (!g->isCellEmpty(info))) throw InvalidMove{};
        }

	for(size_t i = 0; i < BlockSize; ++i){
		g->setEmpty(theBlock.at(i)); // clear original block in grid
	}

	for(size_t i = 0; i < BlockSize; ++i){
		++theBlock.at(i).row; // update block
		g->setShape(theBlock.at(i)); // update grid
	}
}



void Block::clockwise(Grid *g){
	vector<info> newBlock = this->cwInfo(g);

	for(size_t i = 0; i < BlockSize; ++i){
		if (newBlock.at(i).col = 11 - 1) throw InvalidMove{}; //TODO:: constant
		if ((!isInBlock(newBlock.at(i))) && (!g->isCellEmpty(newBlock.at(i)))) throw InvalidMove{};
	}

	for(size_t i = 0; i < BlockSize; ++i){
		g->setEmpty(theBlock.at(i)); // clear original block in grid
	}
	
	theBlock = std::move(newBlock); // update block

	for(size_t i = 0; i < BlockSize; ++i){
		g->setShape(theBlock.at(i)); // update grid
	}
}
        
void Block::counterClockwise(Grid *g){
	vector<info> newBlock = this->ccwInfo(g);

	for(size_t i = 0; i < BlockSize; ++i){
		if (newBlock.at(i).col = 11 - 1) throw InvalidMove{}; //TODO:: constant
		if ((!isInBlock(newBlock.at(i))) && (!g->isCellEmpty(newBlock.at(i)))) throw InvalidMove{};
	}

	for(size_t i = 0; i < BlockSize; ++i){
		g->setEmpty(theBlock.at(i)); // clear original block in grid
	}

	theBlock = std::move(newBlock); // update block

	for(size_t i = 0; i < BlockSize; ++i){
		g->setShape(theBlock.at(i)); // update grid
	}
}





// update theBlock after clearLine
void Block::updateClear(size_t line){
	vector<Info> temp;
	for (size_t i = 0; i < blockSize; ++i){
		if (theBlock.at(i).row != line) {
			temp.emplace_back{Info{theBlock.at(i).row - 1, theBlock.at(i).col. theBlock.at(i).shape}};
		} else {
			--blockSize;
		}
	}
	theBlock = std::move(temp);
}

int Block::getSize(){
	return blockSize;	
}

int Block::getScore(){
	return level * level;	
}
