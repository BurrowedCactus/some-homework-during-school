#include "score.h"

void Score::setHighScore(int newHS){
	highScore = newHS;
}

void Score::setCurrentScore(int newCS){
	score = newCS;
}

int Score::getHighScore(){
	return score;
}

int Score::getCurrentScore(){
	return highScore;
}
