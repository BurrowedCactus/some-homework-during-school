*#ifndef DISPLAY_H
#define DISPLAY_H
#include <iostream>
#include <vector>
#include "observer.h"
#include "state.h"
#include "info.h"
#include "cell.h"
#include <string>
#include "constants.h"

class Cell;
class Display: public Observer {
	Score* score;
	Level* level;
	Shape* nextBlock;
protected:
	std::string getLevel();
	std::string getScore();
	std::string getHighScore();
	std::string getStrNext();
public:
	Display(Level* level, Score* score, Shape* nextBlock);
	virtual void notify(Subject &whoNotified) = 0;
};

#endif
