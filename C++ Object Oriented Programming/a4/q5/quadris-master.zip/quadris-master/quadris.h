#ifndef QUADRIS_H
#define QUADRIS_H
#include <memory>
#include <vector>
#include <math.h>
#include "cell.h"
#include "block.h"
#include "grid.h"

class InvalidMove{};

class Quadris{

private:
	std::unique_ptr<TextDisplay> td;
	std::unique_ptr<GraphicDisplay> gd;
	std::unique_ptr<Grid> g;
	std::unique_ptr<Level> level;
	std::unique_ptr<Score> score;
	std::unique_ptr<Block> currentBlock(nullptr);
	Shape *nextShape = nullptr;
	std::vector<Block*> blockList;

public:
	void Quadris(int winSize = 500);
	void genBlock();
	void drop();
	void moveLeft();
	void moveRight();
	void moveUp();
	void moveDown();
	void clockwise();
	void counterClockwise();
};

#endif
