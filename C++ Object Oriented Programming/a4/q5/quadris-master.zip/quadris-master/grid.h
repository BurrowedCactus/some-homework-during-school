#ifndef GRID_H
#define GRID_H
#include <vector>
#include "cell.h"
#include "info.h"
#include "subject.h"
#include "constants.h"

class Block;
class Score;
class Level;
//class InvalidMove{};
class TextDisplay;
class GraphicsDisplay;


class Grid {
	std::vector<std::vector<Cell>> theGrid;
	//std::vector<Block> list;
	//Block* currentBlock = nullptr;
	TextDisplay* td; 
	GraphicsDisplay* gd;  
	//Score* score;

	void clearLine(size_t line);
	bool isLineFull(size_t line);


public:
	Grid(TextDisplay* td, GraphicsDisplay* gd);
	void setObserver();
	void restart();
	bool isCellEmpty(Info info);
	void setEmpty (Info info);
	void setShape (Info info);
	std::vector<size_t> checkClear();
};

#endif
